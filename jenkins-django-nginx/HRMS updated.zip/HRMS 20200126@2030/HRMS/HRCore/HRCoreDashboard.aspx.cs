﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HRCore_HRCoreDashboard : System.Web.UI.Page
{
    static string username;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {

            if (Session["uname"] == null)
            {
                Response.Redirect("~/Default.aspx");
            }
            else
            {
                username = Session["uname"].ToString();
            }
        }
        }
}