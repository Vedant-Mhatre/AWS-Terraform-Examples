﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class HRCoreMasDesg : System.Web.UI.Page
{
    globalClass obj = new globalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                obj.dbOpen();
                string query = "select desg_id,desg_desc  from Mas_HR_Desg";

                obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridDesg.DataSource = obj.sqlDs;
                GridDesg.DataBind();
                //GridDesg.Caption = "Designation List";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

        protected void OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "cmdUpdate")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridDesg.Rows[index];
                
                string key = row.Cells[2].Text;
                Response.Redirect("HRCoreMasDesgUpdate.aspx?did=" + row.Cells[0].Text+
                    "&desc=" + row.Cells[1].Text );
        }
        }


    protected void cmdSearch_Click(object sender, EventArgs e)
    {
        try
        {
           
            {
                obj.dbOpen();
                string query = "select desg_id,desg_desc  from Mas_HR_Desg where desg_id like '%" + TxtSearch .Text+ "%'";

                obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridDesg.DataSource = obj.sqlDs;
                GridDesg.DataBind();
                GridDesg.Caption = "Designation List";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}