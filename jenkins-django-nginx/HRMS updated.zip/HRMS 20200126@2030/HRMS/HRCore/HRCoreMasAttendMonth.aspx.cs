﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class HRCoreMasAttendMonth : System.Web.UI.Page
{
    static string username,EmpNo;
    globalClass obj = new globalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {

                if (Session["uname"] == null)
                {
                    Response.Redirect("Default.aspx");
                }
                else
                {
                    username = Session["uname"].ToString();
                }
                obj.dbOpen();

                EmpNo = Request.QueryString["empno"];
                if (EmpNo == null)
                {
                    EmpNo = "%%";
                }
                

                string query = "select emp_id \"ID\", emp_name \"Name\",office \"Office\",dept \"Department\"," +
                    "desg \"Designation\",lvl \"Level\",monyr \"Year Month\",tot_days \"Total Days of Month\",attend \"Total Attendance\"" +
                    " from view_hr_month_attend WHERE emp_id like '" + EmpNo+"' ";

                obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridAtt.DataSource = obj.sqlDs;
                GridAtt.DataBind();
             //  GridAtt.Caption = "Attendance Sheet";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

       
    protected void cmdSearch_Click(object sender, EventArgs e)
    {
        try
        {
           
            {
                obj.dbOpen();
                string query = "select emp_id \"Employee ID\", emp_name \"Name\",office \"Office\",dept \"Department\"," +
                    "desg \"Designation\",lvl \"Level\",monyr \"Year Month\",tot_days \"Total Days of Month\",attend \"Total Attendance\"" +
                    " from view_hr_month_attendd where emp_id like '%" + TxtSearch.Text + "%'";

                obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridAtt.DataSource = obj.sqlDs;
                GridAtt.DataBind();
                GridAtt.Caption = "Attendance Sheet";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    
}