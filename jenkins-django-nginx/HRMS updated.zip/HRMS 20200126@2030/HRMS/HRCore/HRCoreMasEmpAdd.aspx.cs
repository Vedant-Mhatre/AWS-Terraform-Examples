﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class HRCoreMasEmpAdd : System.Web.UI.Page
{
    globalClass obj = new globalClass();
    string empno;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
              
                obj.dbOpen();

                // for office
                obj.Query = "select off_id, off_nm from Mas_HR_Office";
                obj.MySqlCmd = new MySqlCommand(obj.Query,obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);

                DropOffice.DataTextField = obj.sqlDs.Tables[0].Columns["off_nm"].ToString();
                DropOffice.DataValueField = obj.sqlDs.Tables[0].Columns["off_id"].ToString();
                DropOffice.DataSource = obj.sqlDs.Tables[0];
                DropOffice.DataBind();
                DropOffice.Items.Insert(0, new ListItem("Select"));

                // for department
                obj.Query = "select dept_id_key from Mas_HR_Dept";
                obj.MySqlCmd = new MySqlCommand(obj.Query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);


                DropDept.DataTextField = obj.sqlDs.Tables[0].Columns["dept_id_key"].ToString();
                DropDept.DataValueField = obj.sqlDs.Tables[0].Columns["dept_id_key"].ToString();
                DropDept.DataSource = obj.sqlDs.Tables[0];
                DropDept.DataBind();
                DropDept.Items.Insert(0, new ListItem("Select"));

                // for designation
                obj.Query = "select desg_id, desg_desc from Mas_HR_Desg";
                obj.MySqlCmd = new MySqlCommand(obj.Query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);


                DropDesg.DataTextField = obj.sqlDs.Tables[0].Columns["desg_desc"].ToString();
                DropDesg.DataValueField = obj.sqlDs.Tables[0].Columns["desg_id"].ToString();
                DropDesg.DataSource = obj.sqlDs.Tables[0];
                DropDesg.DataBind();
                DropDesg.Items.Insert(0, new ListItem("Select"));

                // for level of pay
                obj.Query = "select lvl_id, lvl_desc from Mas_HR_LvlEmp";
                obj.MySqlCmd = new MySqlCommand(obj.Query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);


                DropLvl.DataTextField = obj.sqlDs.Tables[0].Columns["lvl_desc"].ToString();
                DropLvl.DataValueField = obj.sqlDs.Tables[0].Columns["lvl_id"].ToString();
                DropLvl.DataSource = obj.sqlDs.Tables[0];
                DropLvl.DataBind();
                DropLvl.Items.Insert(0, new ListItem("Select"));

                obj.dbClose();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            
        }
    }

    protected void cmdSave_Click1(object sender, EventArgs e)
    {
        try
        {
            obj.dbOpen();
            string query = "select LPAD(count(*)+1, 4, 0) empno from Mas_HR_Emp  ";

            obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
            obj.MySqlRead = obj.MySqlCmd.ExecuteReader();

            if (obj.MySqlRead.Read())
            {
                empno = obj.MySqlRead["empno"].ToString();
            }
            obj.dbClose();

            obj.dbOpen();
            obj.MySqlCmd = new MySqlCommand
              ("insert into Mas_HR_Emp values ('"
                + empno + "','"
                + TxtName.Text + "','"
                + TxtDob.Text + "','"
                + DropGender.SelectedValue + "','"
                + TxtDoa.Text + "','"
                + TxtPAN.Text + "','"
                + TxtAdhar.Text + "','"
                + TxtContact.Text + "','"
                + TxtEmail.Text + "','"
                + DropOffice.SelectedValue + "','"
                + DropDept.SelectedValue + "','"
                + DropDesg.SelectedValue + "','"
                + DropLvl.SelectedValue + 
                "')", 
                obj.MySqlConn);
            obj.MySqlCmd.ExecuteNonQuery();

            // FOR ROLE AND USER ID
            if (DropRole.SelectedValue == "HRM")
            {
                obj.MySqlCmd = new MySqlCommand
                ("insert into Mas_user_auth values ('"
                  + empno + "','"
                  + empno + "','HRM','USER' , NOW() )",
                  obj.MySqlConn);
                obj.MySqlCmd.ExecuteNonQuery();

            }
            else
            {
                obj.MySqlCmd = new MySqlCommand
                ("insert into Mas_user_auth values ('"
                + empno + "','"
                + empno + "', 'EMP' , 'USER' , NOW() )",
                obj.MySqlConn);
                obj.MySqlCmd.ExecuteNonQuery();

            }

            obj.dbClose();
            // to display message
            string message = empno + " is generated successfully!"; 
            string script = "window.onload = function(){ alert('";
            script += message;
            script += "');";
            script += "window.location = '";
            script += Request.Url.AbsoluteUri;
            script += "'; }";
            ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}