﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class HRCoreMasLvlAdd : System.Web.UI.Page
{
    globalClass obj = new globalClass();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void cmdSave_Click(object sender, EventArgs e)
    {
        try
        {
            obj.dbOpen();
            obj.MySqlCmd = new MySqlCommand
                ("insert into Mas_HR_LvlEmp values ('" + TxtLvlId.Text + "','" +
                TxtDesc.Text + "')", obj.MySqlConn);
            obj.MySqlCmd.ExecuteNonQuery();
            obj.dbClose();
            // to display message
            string message = "Your details have been saved successfully.";
            string script = "window.onload = function(){ alert('";
            script += message;
            script += "');";
            script += "window.location = '";
            script += Request.Url.AbsoluteUri;
            script += "'; }";
            ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
            
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}