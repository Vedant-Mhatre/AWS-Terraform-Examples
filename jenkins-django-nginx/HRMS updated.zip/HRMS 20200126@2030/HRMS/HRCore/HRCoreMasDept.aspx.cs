﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class HRCoreMasDept : System.Web.UI.Page
{
    globalClass obj = new globalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                obj.dbOpen();
                string query = "select dept_id , dept_sub_id , dept_id_key , dept_desc  from Mas_HR_Dept";

                obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridDept.DataSource = obj.sqlDs;
                GridDept.DataBind();
                //GridDept.Caption = "Department List";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

        protected void OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "cmdUpdate")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridDept.Rows[index];
                
                string key = row.Cells[2].Text;
                Response.Redirect("HRCoreMasDeptUpdate.aspx?dno=" + row.Cells[0].Text+
                    "&did=" + row.Cells[1].Text +
                    "&key=" + row.Cells[2].Text +
                    "&desc=" + row.Cells[3].Text );
        }
        }


    protected void cmdSearch_Click(object sender, EventArgs e)
    {
        try
        {
           
            {
                obj.dbOpen();
                string query = "select dept_id , dept_sub_id , dept_id_key , dept_desc  from Mas_HR_Dept where dept_id like '%"+ TxtSearch .Text+ "%' or dept_sub_id like '"+TxtSearch.Text+"'";

                obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridDept.DataSource = obj.sqlDs;
                GridDept.DataBind();
                GridDept.Caption = "Department List";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}