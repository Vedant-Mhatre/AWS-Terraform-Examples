﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HRCore_CoreMasterPage : System.Web.UI.MasterPage
{
    globalClass obj = new globalClass();
    static string uid, unm, office, desg, dept, lvl;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uname"] == null)
        {
            Response.Redirect("~/Default.aspx");
        }
        else
        {
            uid = Session["uname"].ToString();
            obj.dbOpen();
            obj.Query = "  select emp_name, func_office(off_id)office, " +
                "func_dept(dept_id_key) dept,func_desg(desg_id) desg, lvl_id lvl " +
                "from mas_hr_emp where emp_id = '" + uid + "'";

            obj.MySqlCmd = new MySqlCommand(obj.Query, obj.MySqlConn);

            obj.MySqlRead = obj.MySqlCmd.ExecuteReader();
            if (obj.MySqlRead.Read())
            {
                unm = obj.MySqlRead["emp_name"].ToString();
                office = obj.MySqlRead["office"].ToString();
                desg = obj.MySqlRead["desg"].ToString();
                dept = obj.MySqlRead["dept"].ToString();
                lvl = obj.MySqlRead["lvl"].ToString();

            }
            obj.dbClose();

            LblEmpNm.Text = unm + " [ " + uid + " ] ";
           
            /* LblEmpDetails.Text = "[ Office:- " + office + "] [Department:- " + dept + "] " +
                 "[Designation:- " + desg + "] [Level:- " + lvl + "]";*/

        }
    }
}
