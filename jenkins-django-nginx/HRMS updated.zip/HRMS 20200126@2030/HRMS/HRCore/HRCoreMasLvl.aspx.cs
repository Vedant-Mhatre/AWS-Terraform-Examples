﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class HRCoreMasLvl : System.Web.UI.Page
{
    globalClass obj = new globalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                obj.dbOpen();
                string query = "select lvl_id,lvl_desc  from Mas_HR_LvlEmp";

                obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridLvl.DataSource = obj.sqlDs;
                GridLvl.DataBind();
                //GridLvl.Caption = "Level of Employees List";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

        protected void OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "cmdUpdate")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridLvl.Rows[index];
                
                string key = row.Cells[2].Text;
                Response.Redirect("HRCoreMasLvlUpdate.aspx?lid=" + row.Cells[0].Text+
                    "&desc=" + row.Cells[1].Text );
        }
        }

    protected void cmdSearch_Click(object sender, EventArgs e)
    {
        try
        {        
            {
                obj.dbOpen();
                string query = "select lvl_id,lvl_desc  from Mas_HR_LvlEmp where lvl_id like '%" + TxtSearch .Text+ "%'";
                obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridLvl.DataSource = obj.sqlDs;
                GridLvl.DataBind();
                GridLvl.Caption = "Level of Employees List";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}