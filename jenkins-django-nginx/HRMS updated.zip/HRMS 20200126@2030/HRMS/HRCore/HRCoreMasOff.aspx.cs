﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HRCore_HRCoreMasOff : System.Web.UI.Page
{
    globalClass obj = new globalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                obj.dbOpen();
                string query = " select off_id \"ID\",off_nm \"Name\", " +
                  "off_doe \"Establishment Date\", off_longitute  \"Longitute\", off_latitute \"Latitute\" ," +
                  "off_add \"Address\",off_city \"City\", off_state \"State\" , off_country \"Country\" , off_contact \"Contact\" , off_fax \"Fax\", off_mail \"Email\"" +
                  " from mas_hr_office ";

                obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridDept.DataSource = obj.sqlDs;
                GridDept.DataBind();
                //GridDept.Caption = "Office Locations";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    protected void OnRowCommand(object sender, GridViewCommandEventArgs e)
    {
       /* if (e.CommandName == "cmdUpdate")
        {
            int index = Convert.ToInt32(e.CommandArgument);
            GridViewRow row = GridDept.Rows[index];

            string key = row.Cells[2].Text;
            Response.Redirect("HRCoreMasDeptUpdate.aspx?dno=" + row.Cells[0].Text +
                "&did=" + row.Cells[1].Text +
                "&key=" + row.Cells[2].Text +
                "&desc=" + row.Cells[3].Text);
        }*/
    }

    protected void cmdSearch_Click(object sender, EventArgs e)
    {
        try
        {

            {
                obj.dbOpen();
                //ff_id off_nm  off_doe off_longitute   off_latitute off_add off_city off_state   off_country off_contact off_fax off_mail
                string query = " select off_id \"ID\",off_nm \"Name\", " +
                    "off_doe \"Establishment Date\", off_longitute  \"Longitute\", off_latitute \"Latitute\" ," +
                    "off_add \"Address\",off_city \"City\", off_state \"State\" , off_country \"Country\" , off_contact \"Contact\" , off_fax \"Fax\", off_mail \"Email\"" +
                    " from mas_hr_office where off_id like '%" + TxtSearch.Text + "%' or off_city like '" + TxtSearch.Text + "'";

                obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridDept.DataSource = obj.sqlDs;
                GridDept.DataBind();
                GridDept.Caption = "Office Locations";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}