﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class HRCoreMasOffAdd : System.Web.UI.Page
{
    globalClass obj = new globalClass();
    string offno;
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }

      protected void cmdSave_Click(object sender, EventArgs e)
    {
        try
        {
            obj.dbOpen();
            string query = "select LPAD(count(*)+1, 2, 0) off_id from Mas_HR_Office ";

            obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
            obj.MySqlRead = obj.MySqlCmd.ExecuteReader();

            if (obj.MySqlRead.Read())
            {
                offno = obj.MySqlRead["off_id"].ToString();
            }
            obj.dbClose();

            obj.dbOpen();
            obj.MySqlCmd = new MySqlCommand
              ("insert into Mas_HR_Office values ('"
                + offno + "','"
                + TxtName.Text + "','"
                + TxtEstDate.Text + "','"
                + TxtLong.Text + "','"
                + TxtLang.Text + "','"
                + TxtAdd.Text + "','"
                + TxtCity.Text + "','"
                + TxtState.Text + "','"
                + TxtCounty.Text + "','"
                + TxtContact.Text + "','"
                + TxtFax.Text + "','"
                + TxtEmail.Text + "')",
                obj.MySqlConn);
            obj.MySqlCmd.ExecuteNonQuery();
            obj.dbClose();
            // to display message
            string message = offno + " is generated successfully!";
            string script = "window.onload = function(){ alert('";
            script += message;
            script += "');";
            script += "window.location = '";
            script += Request.Url.AbsoluteUri;
            script += "'; }";
            ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}