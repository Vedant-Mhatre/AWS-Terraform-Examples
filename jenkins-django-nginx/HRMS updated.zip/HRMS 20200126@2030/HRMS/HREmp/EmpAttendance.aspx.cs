﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;
using System.Drawing;

public partial class EmpAttendance : System.Web.UI.Page
{
    globalClass obj = new globalClass();
    string username;
    string todate,tabuser,tabin,tabout;
    static string flag;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                if (Session["uname"] == null)
                {
                    Response.Redirect("~/Default.aspx");
                }
                else
                {
                    username = Session["uname"].ToString();
                }
                todate = DateTime.Today.ToString("yyyy-MM-dd");
                obj.dbOpen();
                obj.Query = "  SELECT  emp_id,dt_in, dt_out , flag FROM  tran_emp_attend " +
                    "WHERE emp_id='" + username + "' AND  date(dt_in) ='" + todate + "'";

                obj.MySqlCmd = new MySqlCommand(obj.Query, obj.MySqlConn);

                obj.MySqlRead = obj.MySqlCmd.ExecuteReader();
                if (obj.MySqlRead.Read())
                {
                    tabuser = obj.MySqlRead["emp_id"].ToString();
                    tabin = obj.MySqlRead["dt_in"].ToString();
                    tabout = obj.MySqlRead["dt_out"].ToString();
                    flag = obj.MySqlRead["flag"].ToString();
                }

                if (flag == "IN")
                {
                    LblTime.Text = "Login time is :" + tabin;
                    LblTime.ForeColor = Color.Green;
                    CmdClock.Text = "Clock OUT";
                    ImgLogin.Visible = true; ImgLogout.Visible = false; ImgLognot.Visible = false;
                    ImgLogin.ImageUrl = "img/login.png";
                }
                else if (flag == "OUT")
                {
                    LblTime.Text = "Already logged out  ";
                    LblTime.ForeColor = Color.Red;
                    CmdClock.Text = "Day Called off";
                    CmdClock.Enabled = false;
                    ImgLogin.Visible = false; ImgLogout.Visible = true; ImgLognot.Visible = false;
                    ImgLogout.ImageUrl = "img/logout.png";
                }
                else
                {
                    LblTime.Text = "Not yet to Mark Attendance in  ";
                    LblTime.ForeColor = Color.Blue;
                    CmdClock.Text = "Clock IN";
                    ImgLogin.Visible = false; ImgLogout.Visible = false; ImgLognot.Visible = true;
                    ImgLognot.ImageUrl = "img/notlogin.png";

                }
                obj.dbClose();

            }
            catch (Exception ex) { Response.Write(ex.Message); }
        }
    }

    protected void CmdClock_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["uname"] == null)
            {
                Response.Redirect("Default.aspx");
            }
            else
            {
                username = Session["uname"].ToString();
            }

            todate = DateTime.Today.ToString("yyyy-MM-dd");

            if (flag != "IN")
            {
                obj.dbOpen();
                obj.MySqlCmd = new MySqlCommand
                     ("insert into tran_emp_attend values ('" + username + "',NOW(),NULL,'IN','" + username + "',NOW())", obj.MySqlConn);
                obj.MySqlCmd.ExecuteNonQuery();
                obj.dbClose();
                // to display message
                string message = "CLOCK IN ";
                string script = "window.onload = function(){ alert('";
                script += message;
                script += "');";
                script += "window.location = '";
                script += Request.Url.AbsoluteUri;
                script += "'; }";
                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
            }
            else if (flag == "IN")
            {
                obj.dbOpen();
                obj.MySqlCmd = new MySqlCommand
                     ("UPDATE tran_emp_attend SET FLAG = 'OUT', DT_OUT = NOW() WHERE EMP_ID ='"+username+ "' AND date(dt_in) ='" + todate + "'" , obj.MySqlConn);
                obj.MySqlCmd.ExecuteNonQuery();
                obj.dbClose();
                // to display message
                string message = "CLOCK OUT ";
                string script = "window.onload = function(){ alert('";
                script += message;
                script += "');";
                script += "window.location = '";
                script += Request.Url.AbsoluteUri;
                script += "'; }";
                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
            }
            
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}