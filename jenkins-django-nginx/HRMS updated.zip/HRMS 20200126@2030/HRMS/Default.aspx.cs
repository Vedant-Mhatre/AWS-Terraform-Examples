﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class Default : System.Web.UI.Page
{
    globalClass obj = new globalClass();
    static string user, pwd, role = null;
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }


    protected void cmdSave_Click(object sender, EventArgs e)
    {
        //write code here for
        obj.dbOpen();
        obj.Query = "  SELECT * FROM hrms.mas_user_auth  " +
            "WHERE emp_id='" + TxtLogin.Text + "' AND  pwd ='" + TxtPwd.Text + "'";

        obj.MySqlCmd = new MySqlCommand(obj.Query, obj.MySqlConn);

        obj.MySqlRead = obj.MySqlCmd.ExecuteReader();
        if (obj.MySqlRead.Read())
        {
            user = obj.MySqlRead["emp_id"].ToString();
            pwd = obj.MySqlRead["pwd"].ToString();
            role = obj.MySqlRead["usrrole"].ToString();

        }
        obj.dbClose();

        if (TxtLogin.Text == user && TxtPwd.Text == pwd && role =="HRADM")
        {
            Session["uname"] = TxtLogin.Text;
            Response.Redirect("DefaultRole.aspx");
        }
        else if (TxtLogin.Text == user && TxtPwd.Text == pwd)
           {
            Session["uname"] = TxtLogin.Text;
            Response.Redirect("~/HREmp/EmpDashboard.aspx");
        }
        else
        {
            string message = "Invalied User id and password!";
            string script = "window.onload = function(){ alert('";
            script += message;
            script += "');";
            script += "window.location = '";
            script += Request.Url.AbsoluteUri;
            script += "'; }";
            ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
        }
    }
}