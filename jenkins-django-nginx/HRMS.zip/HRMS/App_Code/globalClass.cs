﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.OleDb;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;


public class globalClass
{
    public string Query;
    public MySqlConnection MySqlConn;
    public MySqlCommand MySqlCmd;
    public MySqlDataReader MySqlRead;
    public MySqlDataAdapter MySqlAdpt;
    public DataSet sqlDs;
    public void dbOpen()
    {
        /*MySqlConn = new MySqlConnection
            ("datasource=localhost;port=3307;database=hrms;username=root;password=mysql"); */
        MySqlConn = new MySqlConnection
            ("datasource=sapiohrms2.c6mra3prmuw5.ap-south-1.rds.amazonaws.com;user id=admin;persistsecurityinfo=True;database=hrms;" +
            "port=3306;" +
            "database=hrms;" +
            "username=admin;" +
            "password=Get_sapio123");
        MySqlConn.Open();
    }
    public void dbClose()
    {
        MySqlConn.Close();
    }  
}




