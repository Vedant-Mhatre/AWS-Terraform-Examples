﻿
Partial Class HRCore_test
    Inherits System.Web.UI.Page

End Class
