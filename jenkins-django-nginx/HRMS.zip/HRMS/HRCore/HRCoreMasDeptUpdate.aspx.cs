﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class HRCoreMasDeptUpdate : System.Web.UI.Page
{
    globalClass obj = new globalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                TxtDeptId.Text = Request.QueryString["dno"];
                TxtDeptSubId.Text = Request.QueryString["did"];
                TxtDeptKey.Text = Request.QueryString["key"];
                TxtDesc.Text = Request.QueryString["desc"];
            }
        }
        catch (Exception ex)
        {
            string message = ex.Message;
            string script = "window.onload = function(){ alert('";
            script += message;
            script += "');";
            script += "window.location = '";
            script += Request.Url.AbsoluteUri;
            script += "'; }";
            ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
        }
    }
        protected void cmdSave_Click(object sender, EventArgs e)
        {
            try
            {
            
                obj.dbOpen();
                obj.MySqlCmd = new MySqlCommand
                    ("update Mas_HR_Dept set dept_desc = '" + TxtDesc.Text + "' where dept_id_key = '"+TxtDeptKey.Text+"'", obj.MySqlConn);
                obj.MySqlCmd.ExecuteNonQuery();
                obj.dbClose();
                // to display message
                string message = "Record Updated successfully.";
                string script = "window.onload = function(){ alert('";
                script += message;
                script += "');";
                script += "window.location = '";
                script += Request.Url.AbsoluteUri;
                script += "'; }";
                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);

            TxtDeptId.Text = "";
            TxtDeptSubId.Text = "";
            TxtDeptKey.Text = "";
            TxtDesc.Text = "";
        }
            catch (Exception ex)
            {
                string message = ex.Message;
                string script = "window.onload = function(){ alert('";
                script += message;
                script += "');";
                script += "window.location = '";
                script += Request.Url.AbsoluteUri;
                script += "'; }";
                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
        }
        }
}