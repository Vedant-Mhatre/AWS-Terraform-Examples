﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class HRCoreMasEmp : System.Web.UI.Page
{
    globalClass obj = new globalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                obj.dbOpen();
                string query = "select  off_id,dept_id_key,lvl_id,emp_id,emp_name,date_format(emp_dob,'%d/%m/%Y') emp_dob" +
                    ",date_format(doj,'%d/%m/%Y')doj,desg_id  from Mas_HR_Emp";

                obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridEmp.DataSource = obj.sqlDs;
                GridEmp.DataBind();
               // GridEmp.Caption = "Employee List";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

        protected void OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
        if (e.CommandName == "cmdAttd")
         {
             int index = Convert.ToInt32(e.CommandArgument);
             GridViewRow row = GridEmp.Rows[index];

             string key = row.Cells[2].Text;
            Response.Redirect("HRCoreMasAttend.aspx?empno=" + row.Cells[3].Text);
            //+ "&yrmon=" + row.Cells[1].Text );
         }
        
    }


    protected void cmdSearch_Click(object sender, EventArgs e)
    {
        try
        {
           
            {
                obj.dbOpen();
                string query = "select  off_id,dept_id_key,lvl_id,emp_id,emp_name,date_format(emp_dob,'%d/%m/%Y') emp_dob" +
                    ",date_format(doj,'%d/%m/%Y')doj,desg_id  from Mas_HR_Emp " +
                    "where emp_name like '%" + TxtSearch.Text + "%'" +
                    "or off_id like '%" + TxtSearch.Text + "%'" +
                    "or dept_id_key like '%" + TxtSearch.Text + "%'" +
                    "or desg_id like '%" + TxtSearch.Text + "%'" +
                    "or lvl_id like '%" + TxtSearch.Text + "%'";

                obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridEmp.DataSource = obj.sqlDs;
                GridEmp.DataBind();
                GridEmp.Caption = "Employee List";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}