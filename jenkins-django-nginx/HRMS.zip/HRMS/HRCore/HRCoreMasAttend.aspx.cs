﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class HRCoreMasAttend : System.Web.UI.Page
{
    static string username,EmpNo;
    globalClass obj = new globalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {

                if (Session["uname"] == null)
                {
                    Response.Redirect("~/Default.aspx");
                }
                else
                {
                    username = Session["uname"].ToString();
                }
                obj.dbOpen();

                EmpNo = Request.QueryString["empno"];
                if (EmpNo == null)
                {
                    EmpNo = "%%";
                }


                string query = 
                    "SELECT m.emp_id \"ID\", emp_name \"Name\",func_office(off_id)\"Office\",dept_id_key \"Department\", " +
                    "func_desg(desg_id) \"Designation\",lvl_id \"Level\",  dt_in \"Login\", dt_out \"Logout\", att_status \"Status\" " +
                    "FROM view_hr_att_sheet  v, mas_hr_emp m " +
                    "where v.emp_id = m.emp_id and m.emp_id like '" + EmpNo + "' ";

                obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridAtt.DataSource = obj.sqlDs;
                GridAtt.DataBind();
                //GridAtt.Caption = "Attendance Sheet";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }


    protected void cmdSearch_Click(object sender, EventArgs e)
    {
        try
        {
           
            {
                obj.dbOpen();
                string query =
                   "SELECT m.emp_id \"ID\", emp_name \"Name\",func_office(off_id)\"Office\",dept_id_key \"Department\", " +
                    "func_desg(desg_id) \"Designation\",lvl_id \"Level\",  dt_in \"Login\", dt_out \"Logout\", att_status \"Status\" " +
                    "FROM view_hr_att_sheet  v, mas_hr_emp m " +
                    "where v.emp_id = m.emp_id and m.emp_id like %'" + TxtSearch.Text + "'% ";

                obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridAtt.DataSource = obj.sqlDs;
                GridAtt.DataBind();
                GridAtt.Caption = "Attendance Sheet";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    protected void cmdLeave_Click(object sender, EventArgs e)
    {
        obj.dbOpen();
        string query = "SELECT * FROM VIEW_HR_EMP_LEAVE_TODAY";

        obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
        obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
        obj.sqlDs = new DataSet();
        obj.MySqlAdpt.Fill(obj.sqlDs);
        obj.dbClose();

        GridAtt.DataSource = obj.sqlDs;
        GridAtt.DataBind();
        GridAtt.Caption = "Employee Leave List";
    }

    protected void cmdOnBoard_Click(object sender, EventArgs e)
    {
        obj.dbOpen();
        string query =
             "SELECT m.emp_id \"ID\", emp_name \"Name\",func_office(off_id) \"Office\",dept_id_key \"Department\", " +
                    "func_desg(desg_id) \"Designation\",lvl_id \"Level\",  dt_in \"Login\", dt_out \"Logout\", att_status \"Status\" " +
                    "FROM view_hr_att_sheet  v, mas_hr_emp m where v.emp_id = m.emp_id " +
                   "and  m.emp_id like '" + EmpNo + "' and date(dt_in) = date(now()) ";

        obj.MySqlCmd = new MySqlCommand(query, obj.MySqlConn);
        obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
        obj.sqlDs = new DataSet();
        obj.MySqlAdpt.Fill(obj.sqlDs);
        obj.dbClose();

        GridAtt.DataSource = obj.sqlDs;
        GridAtt.DataBind();
        GridAtt.Caption = "On Board List";
    }
}