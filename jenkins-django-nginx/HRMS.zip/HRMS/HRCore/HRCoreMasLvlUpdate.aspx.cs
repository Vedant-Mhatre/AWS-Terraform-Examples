﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Data;

public partial class HRCoreMasLvlUpdate : System.Web.UI.Page
{
    globalClass obj = new globalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                Txtlvlid.Text = Request.QueryString["lid"];
                TxtDesc.Text = Request.QueryString["desc"];
            }
        }
        catch (Exception ex)
        {
            string message = ex.Message;
            string script = "window.onload = function(){ alert('";
            script += message;
            script += "');";
            script += "window.location = '";
            script += Request.Url.AbsoluteUri;
            script += "'; }";
            ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
        }
    }
        protected void cmdSave_Click(object sender, EventArgs e)
        {
            try
            {
            
                obj.dbOpen();
                obj.MySqlCmd = new MySqlCommand
                    ("update Mas_HR_LvlEmp set lvl_desc = '" + TxtDesc.Text + "' where lvl_id = '"+Txtlvlid.Text+"'", obj.MySqlConn);
                obj.MySqlCmd.ExecuteNonQuery();
                obj.dbClose();
                // to display message
                string message = "Record Updated successfully.";
                string script = "window.onload = function(){ alert('";
                script += message;
                script += "');";
                script += "window.location = '";
                script += Request.Url.AbsoluteUri;
                script += "'; }";
                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);

            Txtlvlid.Text = "";
           
            TxtDesc.Text = "";
        }
            catch (Exception ex)
            {
                string message = ex.Message;
                string script = "window.onload = function(){ alert('";
                script += message;
                script += "');";
                script += "window.location = '";
                script += Request.Url.AbsoluteUri;
                script += "'; }";
                ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
        }
        }
}