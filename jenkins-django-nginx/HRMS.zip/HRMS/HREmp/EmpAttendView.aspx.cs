﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HREmp_EmpAttendView : System.Web.UI.Page
{
    static string flag,Empno;
    globalClass obj = new globalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                flag = Request.QueryString["flag"].ToString();
                if (flag == null)
                {
                    Response.Redirect("~/Default.aspx");
                }
                else
                {
                    Empno = Session["uname"].ToString();
                }
                if (flag == "D")
                {
                    obj.Query =
                                "SELECT " +
                                "dt_in \"Login\", dt_out \"Logout\", att_status \"Status\" " +
                                "FROM view_hr_att_sheet  v, mas_hr_emp m " +
                                "where v.emp_id = m.emp_id and m.emp_id like '" + Empno + "' order by dt_in";
                    LblHeader.Text = "My Daily Attendance Sheet";
                }
                else
                {
                    obj.Query = 
                        "select monyr \"Year Month\",tot_days \"Total Days of Month\",attend \"Total Attendance\"" +
                        " from view_hr_month_attend WHERE emp_id like '" + Empno + "' ";
                    LblHeader.Text = "My Monthly Attendance Sheet";
                }
                obj.dbOpen();
                obj.MySqlCmd = new MySqlCommand(obj.Query, obj.MySqlConn);
                obj.MySqlAdpt = new MySqlDataAdapter(obj.MySqlCmd);
                obj.sqlDs = new DataSet();
                obj.MySqlAdpt.Fill(obj.sqlDs);
                obj.dbClose();

                GridAtt.DataSource = obj.sqlDs;
                GridAtt.DataBind();
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}