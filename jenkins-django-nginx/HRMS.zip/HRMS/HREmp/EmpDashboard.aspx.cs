﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HREmp_EmpDashboard : System.Web.UI.Page
{
    globalClass obj = new globalClass();
    static string unm,gender,FName,FPath;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uname"] == null)
        {
            Response.Redirect("~/Default.aspx");
        }
        else
        {
            unm = Session["uname"].ToString();
            try
            {
                obj.dbOpen();
                obj.Query = "  select `m`.`emp_id` AS `emp_id`,DATE_FORMAT(emp_dob,'%d/%m/%Y') emp_dob,DATE_FORMAT(doj,'%d/%m/%Y') doj ,pan_num, aadhar_num,contact_num,email, gender," +
                    " `m`.`emp_name` AS `emp_name`, " +
                    " FUNC_OFFICE(`m`.`off_id`) AS `off_id`,  " +
                    " `m`.`dept_id_key` AS `dept_id_key`,        FUNC_DESG(`m`.`desg_id`) AS `desg_id`, " +
                    " `m`.`lvl_id` AS `lvl_id`  from mas_hr_emp m   " +
                    "WHERE emp_id='" + unm +"'";

                obj.MySqlCmd = new MySqlCommand(obj.Query, obj.MySqlConn);

                obj.MySqlRead = obj.MySqlCmd.ExecuteReader();
                if (obj.MySqlRead.Read())
                {
                    LblName.Text = obj.MySqlRead["emp_name"].ToString();
                    Lbldob.Text = obj.MySqlRead["emp_dob"].ToString();
                    Lbldoa.Text = obj.MySqlRead["doj"].ToString();
                    Lblpan.Text = obj.MySqlRead["pan_num"].ToString();
                    Lblaadhar.Text = obj.MySqlRead["aadhar_num"].ToString();
                    Lblmnum.Text = obj.MySqlRead["contact_num"].ToString();
                    Lblemail.Text = obj.MySqlRead["email"].ToString();
                    Lbloff.Text = obj.MySqlRead["off_id"].ToString();
                    LblDept.Text = obj.MySqlRead["dept_id_key"].ToString();
                    Lbldesg.Text = obj.MySqlRead["desg_id"].ToString();
                    LblLvl.Text = obj.MySqlRead["lvl_id"].ToString();
                    gender = obj.MySqlRead["gender"].ToString();
                }
                obj.dbClose();
                if (gender == "M")
                {
                    FPath = "img/EmpImg/" + unm + ".jpg";
                    ProfileImage.ImageUrl = "../../img/emp.jpg";
                    /*if (File.Exists(FPath))
                    {
                        ProfileImage.ImageUrl = "../../img/emp.jpg";                       
                    }
                    else
                    {
                        ProfileImage.ImageUrl = "img/EmpImg/" + unm + ".jpg";
                    }*/
                }
                else if (gender == "F")
                {
                    ProfileImage.ImageUrl = "../../img/femp.jpg";
                }
                
            }
            catch (Exception ex) { Response.Write(ex.Message); }
        }
        
    }

   
}