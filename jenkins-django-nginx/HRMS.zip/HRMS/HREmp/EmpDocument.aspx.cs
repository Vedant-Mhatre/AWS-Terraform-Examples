﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EmpDocument : System.Web.UI.Page
{
    static string FName,unm,msg;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["uname"] == null)
        {
            Response.Redirect("~/Default.aspx");
        }
        else
        {
            unm = Session["uname"].ToString();
        }
    }

    protected void CmdCVUpload_Click(object sender, EventArgs e)
    {
        try
        {
            unm = Session["uname"].ToString();
            FName = Path.GetFileName(FileUpload.PostedFile.FileName);
            FileUpload.SaveAs(Server.MapPath("img/EmpCV/CV" + unm + ".pdf"));
            msg = "File Uploaded Successfully!";
        }
        catch (Exception ex)
        {
            msg = "Error :- " + ex.Message;
        }
        string message = msg;
        string script = "window.onload = function(){ alert('";
        script += message;
        script += "');";
        script += "window.location = '";
        script += Request.Url.AbsoluteUri;
        script += "'; }";
        ClientScript.RegisterStartupScript(this.GetType(), "SuccessMessage", script, true);
    }

    protected void CmdViewCV_Click(object sender, EventArgs e)
    {
        FName = "img/EmpCV/CV" + unm + ".pdf";
        Response.Redirect(FName);
    }

    protected void CmdOfferLetter_Click(object sender, EventArgs e)
    {
        FName = "img/EmpCV/OL" + unm + ".pdf";
        Response.Redirect(FName);
    }

    protected void CmdAttendM_Click(object sender, EventArgs e)
    {
        Response.Redirect("EmpAttendView.aspx?flag=M");
    }

    protected void CmdAttendD_Click(object sender, EventArgs e)
    {
        Response.Redirect("EmpAttendView.aspx?flag=D");
    }
}